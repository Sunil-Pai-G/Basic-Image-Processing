
Requirements:

opencv
numpy
matplotlib

To execute:  sudo /usr/bin/python project.py

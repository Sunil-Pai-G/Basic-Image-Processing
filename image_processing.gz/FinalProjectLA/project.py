import sys


def f1():
	import prj1
def f2():
	import prj2
def f3():
	import prj3
def f4():
	import prj4
def f5():
	import prj5
def f6():
	sys.exit(0)
def default():
	print "\n\nWrong choice. Please try again! "


choices = { 1:f1, 2:f2, 3:f3, 4:f4, 5:f5, 6:f6 }

while True:
	
	print "\n\n"
	print "1. Harris Corner Detection"
	print "2. Interactive Foreground Extraction using GrabCut Algorithm"
	print "3. Face Detection"
	print "4. Image Gradients"
	print "5. Canny Edge Detection"
	print "6. Exit"
	print "\n"
	ch=int(input("Enter your choice: "));	
	choices.get(ch,default)()


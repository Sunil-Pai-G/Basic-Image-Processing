'''
Face Detection
'''

import cv2

def nothing(x):
	pass

face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

img = cv2.imread('faces.jpg')
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


cv2.namedWindow('image')
cv2.createTrackbar('minNeighbors','image',1,10,nothing)
cv2.createTrackbar('scaleFactor','image',1100,5000,nothing)
cv2.createTrackbar('minSizeX','image',20,100,nothing)
cv2.createTrackbar('minSizeY','image',20,100,nothing)

while(1):	
	img = cv2.imread('faces.jpg')
	gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
	
	k = cv2.waitKey(1) & 0xFF
	if k==27:
		break
	
	sf=max(1100, cv2.getTrackbarPos('scaleFactor','image')) * 0.001
	mn=cv2.getTrackbarPos('minNeighbors','image')
	minSizeX=cv2.getTrackbarPos('minSizeX','image')
	minSizeY=cv2.getTrackbarPos('minSizeY','image')		
	faces = face_cascade.detectMultiScale(gray, scaleFactor=sf,minNeighbors=mn,minSize=(minSizeX,minSizeY),flags = cv2.cv.CV_HAAR_SCALE_IMAGE)
	
	for (x,y,w,h) in faces:
		cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2)
		cv2.imshow('image',img)	
	if k==ord('s'):
		cv2.imwrite('face_detected.jpg',img)
		print "Found {0} faces!".format(len(faces))
		break		
cv2.imshow('faces found',img)
cv2.waitKey(0)
cv2.destroyAllWindows()
